package scooter;

public class Scooter {

    public static void main(String[] args) {
        
        //Crear objetos de tipo puesto
        Puesto puestoVendedor = new Puesto("001","Vendedor");
        Puesto puestoGerente = new Puesto("001","Gerente");
        //Crear empleados
        Empleado empleado1 = new Empleado("12.123.456-7", "Juan P�rez",30,5,puestoVendedor);
        Empleado empleado2 = new Empleado("12.123.456-8", "Juan P�rez",30,5,puestoGerente);////
        ////agregar m�s
        //Crear empresa
        Empresa empresa = new Empresa();
        
        //Agregar empleados a la empresa
        empresa.agregarEmpleado(empleado1);
        empresa.agregarEmpleado(empleado2);

        //Mostramos los empleados agregados
        System.out.println("Lista de empleados");
        empresa.listarEmpleados();
        //Eliminamos un empleado por su rut
        empresa.eliminarEmpleado("12.123.456-8");
        
         //Mostramos los empleados nuevamente
        System.out.println("\nLista de empleados actualizada");
        empresa.listarEmpleados();
                
           
    }
    
}
