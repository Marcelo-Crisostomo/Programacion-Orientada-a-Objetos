
package scooter;

public class Empleado {
    private String rut, nombre;
    private int edad, aniosDeServicio;
    private Puesto puesto;////////////

    public Empleado(String rut, String nombre, int edad, int aniosDeServicio, Puesto puesto) {
        this.rut = rut;
        this.nombre = nombre;
        this.edad = edad;
        this.aniosDeServicio = aniosDeServicio;
        this.puesto = puesto;
    }
    
    //Get

    public String getRut() {
        return rut;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public int getAniosDeServicio() {
        return aniosDeServicio;
    }

    public Puesto getPuesto() {
        return puesto;
    }

    @Override
    public String toString() {
        return "Empleado{" + "rut=" + rut + ", nombre=" + nombre + ", edad=" + edad + ", aniosDeServicio=" + aniosDeServicio + ", puesto=" + puesto + '}';
    }
    
    
}
