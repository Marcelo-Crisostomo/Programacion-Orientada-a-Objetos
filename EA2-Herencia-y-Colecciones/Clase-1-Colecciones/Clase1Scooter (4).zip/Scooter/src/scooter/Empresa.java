package scooter;
import java.util.ArrayList;
public class Empresa {
    private ArrayList<Empleado> listaEmpleados;
    
    
    //Constructor que inicaliza la colecci�n o array list

    public Empresa() {
        listaEmpleados = new ArrayList<>();
    }
    //M�todo para agregar un empleado a la colecci�n
    /*
    
    
    * M�todo para agregar un empleado a la coleccion
    *@param empleado: el empleado que ser� agref�gado
    */
    
    public void agregarEmpleado(Empleado empleado){
        listaEmpleados.add(empleado);
    }
    
    /*
    M�todo para eliminar un empleado por su rut
    recibe: como parametro el rut del empleado que se desea eliminar
    */
    
    public void eliminarEmpleado(String rut){
        //Recooremos la lista para poder buscar al empleado por el rut
        for (int i = 0; i<listaEmpleados.size(); i++){////////////
            if (listaEmpleados.get(i).getRut().equals(rut)){////////////
                //Si eso se cumple
                listaEmpleados.remove(i);////////////
                System.out.println("Empleado con RUT "+ rut + " eliminado");
                return;////////////////
            }
        }
        System.out.println("Empleado con rut: "+rut+" no encontrado");
    }
    
    /*M�todo para listar todos los empleados*/
    public void listarEmpleados(){
        for (Empleado empleado : listaEmpleados){////////////
            System.out.println(empleado.toString());
        }
    }
}
