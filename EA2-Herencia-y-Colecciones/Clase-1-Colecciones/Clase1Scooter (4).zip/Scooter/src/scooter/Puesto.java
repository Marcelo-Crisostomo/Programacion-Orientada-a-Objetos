package scooter;
public class Puesto {
    private String codigo;
    private String nombre;
    //C

    public Puesto(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }
    
    //get

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "Puesto{" + "codigo=" + codigo + ", nombre=" + nombre + '}';
    }
    
    
    
    
}
