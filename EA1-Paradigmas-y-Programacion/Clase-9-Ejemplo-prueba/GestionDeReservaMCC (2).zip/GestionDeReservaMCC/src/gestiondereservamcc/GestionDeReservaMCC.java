/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestiondereservamcc;
import java.util.Scanner;

public class GestionDeReservaMCC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // Se crea un objeto de la clase Hotel para gestionar las reservas
         Hotel sistemaReservasHotel = new Hotel();
         
        // Se crea un objeto Scanner para leer la entrada del usuario
        Scanner entradaUsuario = new Scanner(System.in);
        
         // Variable para almacenar la opci�n seleccionada por el usuario
        int opcionMenu;
        
        
        // Reserva inicial vac�a
        Reserva reservaActual = new Reserva(null, null, null);
         
        
        while (true){
            //men�
            System.out.println("Men� de Gesti�n de Reservas:");
            System.out.println("1 - Registrar una nueva reserva.");
            System.out.println("2 - Buscar una reserva por nombre del hu�sped.");
            System.out.println("3 - Salir del sistema.");
            System.out.println("Ingrese el n�mero de la opci�n deseada:");
            
            opcionMenu = entradaUsuario.nextInt(); // Leer la opci�n seleccionada
            entradaUsuario.nextLine(); // Limpiar el salto
            
                   // Manejo de las opciones del men�
                   
            switch(opcionMenu){
                case 1->{
                    String nombreHuesped = "";
                    String codigoReserva = "";
                    String fechaReserva = "";
                    
                    //Solocitar nombre del huesped hasta que no est� vacio
                    while(nombreHuesped.isEmpty()){
                        System.out.println("Ingrese el nombre del hu�sped:");
                        nombreHuesped = entradaUsuario.nextLine();
                        if(nombreHuesped.isEmpty()){
                        System.out.println("Error: El nombre del hu�sped no puede estar vac�o.");
 
                        }
                    }
                    
                      //Solocitar codigo reserva hasta que no est� vacio
                    while(codigoReserva.isEmpty()){
                        System.out.println("Ingrese el codigo de reserva del hu�sped:");
                        codigoReserva = entradaUsuario.nextLine();
                        if(codigoReserva.isEmpty()){
                        System.out.println("Error: El c�digo de la reserva no puede estar vac�o.");
 
                        }
                    }
                    
                        //Solocitar fecha hasta que no est� vacio
                    while(fechaReserva.isEmpty()){
                        System.out.println("Ingrese la fecha de reserva del hu�sped:");
                        fechaReserva = entradaUsuario.nextLine();
                        if(fechaReserva.isEmpty()){
                        System.out.println("Error: La fecha de la reserva no puede estar vac�a.");
 
                        }
                    }
                    
                    //verificar que el c�digo de la reserva sea unico
                    
                    if(!codigoReserva.equals(reservaActual.obtenerCodigoReserva())){
                        //crear l anueva reserva
                        reservaActual= new Reserva(nombreHuesped, codigoReserva, fechaReserva);
                        //registrar la nueva reserva
                        sistemaReservasHotel.registrarReserva(reservaActual);
                        
                    }else{
                        System.out.println("Error: El c�digo de la reserva debe ser �nico.");
                    }
                    
                }
                case 2 ->{
                 // Buscar una reserva por nombre del hu�sped
                String nombreBuscado = "";  // Inicializamos la variable vac�a

                // Solicitar el nombre del hu�sped hasta que no est� vac�o
                while (nombreBuscado.isEmpty()) {
                    System.out.println("Ingrese el nombre del hu�sped para buscar su reserva:");
                    nombreBuscado = entradaUsuario.nextLine();
                    if (nombreBuscado.isEmpty()) {
                        System.out.println("Error: El nombre del hu�sped no puede estar vac�o.");
                    }
                }

                // si todo est� ok Buscar la reserva por nombre del hu�sped
                sistemaReservasHotel.buscarReservaPorNombre(nombreBuscado);
                
                }
                case 3 -> {
                    // Salir del programa
                    System.out.println("Saliendo del sistema de reservas...");
                    entradaUsuario.close();
                    return;
                }
                default -> System.out.println("Opci�n no v�lida, por favor ingrese un n�mero del men�.");
            }
        }
    }
    
}
