/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestiondereservamcc;

/**
 *
 * @author marce
 */
public class Hotel {
    
    private Reserva ultimaReserva;
    //M�todo para agregar una nueva reserva al hotel
    public void registrarReserva(Reserva nuevaReserva){
        this.ultimaReserva = nuevaReserva;
        System.out.println("Reserva registrada exitosamente" + this.ultimaReserva.toString());
    }
    //M�todo para buscar una reserva por el nombre del huesped
    public void buscarReservaPorNombre(String nombreHuespedBuscado){
        //Verificamos si hay una reserva y si el nombre del huesped coincide
        if (ultimaReserva != null && ultimaReserva.obteberNombreHuesped().equalsIgnoreCase(nombreHuespedBuscado)){
            System.out.println("Reserva encontrada: "+ ultimaReserva.toString());
        }else{
            System.out.println("No se encontr� una reserva con ese nombre.");
        }
    }
}
