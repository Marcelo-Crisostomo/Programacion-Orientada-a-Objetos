/*
MAIN
 */
package ejemplostringfor2;
public class EjemploStringFor2 {
    public static void main(String[] args) {
        //Lista o array de plabras
        String[] palabras = {"Java", "JavaScript","Python","CSS","Sass","SQL"};
        
        //iterar sobre cada palabra del arreglo o lista = palabras
        //Declaramos un indice, validaci�n , que se vaya sumando de uno en uno
        for ( int i = 0; i < palabras.length; i++){
            //Que es lo que quiero que pase por cada iteraci�n == repetir
            
            String palabra = palabras[i];
            
            //Obtener la longitud de una palabra
            int longitud = palabra.length();
            System.out.println("La longitud de la palabra es: " + longitud);
            
            //Obtener el primer caracter de la palabra 
            char primerCaracter = palabra.charAt(0);
            System.out.println("El primer caracter de la palabra es: " + primerCaracter);
            
            //Convertir una palabra en may�sculas
            String palabraEnMayusculas = palabra.toUpperCase();
            System.out.println("La palabra en may�sculas es: " + palabraEnMayusculas);
            
            //Convertir palabra en minusculas
            String palabraEnMinusculas = palabra.toLowerCase();
            System.out.println("La palabra en min�sculas es: "+ palabraEnMinusculas);
            
            //Verificar si una palabra comienza comienza con una letra especifica. "J"
            //Si la palabra comienza con J
            if (palabra.startsWith("J")){
                System.out.println("La palbra " +palabra + " Comienza con la letra J ");
            }else{
                System.out.println("La palabra " + palabra + " No comienza con la letra J");
            }
            
            //Verificar si la palabra finaliza con una letra especifica "s"
            if(palabra.endsWith("s")){
                System.out.println("La palabra " + palabra + " Finaliza con la letra s ");
            }else{
                System.out.println("La palabra "+ palabra + " No finaliza con la letra s");
            }
            
            //Vamos a crear una subcadena de una palabra de los 3 primeros caracteres
            //Si longitud es igual o mayor a 3 // Longitud tiene el total de caracteres.
            if (longitud >=3){
                //Almacenando la subcadena(3 caracteres) en una variable con substring();
                String subcadena = palabra.substring(0,3);
                //Jav
                System.out.println("La subcadena de la palabra " + palabra + " Es: " + subcadena);
            }
            
            //Reemplazar un caracter especifico por otro caracter
            //Replace recibe 2 argumentos la letra que quiero cambiar y la letra a reemplazar
            String palabraReemplazada = palabra.replace("a", "@");
            System.out.println("Palabra reemplazada con @ " + palabraReemplazada);
            
            //Comparar una palabra es igual a la de la lista ignorando may�sculas y min�sculas
            // java = true
            if(palabra.equalsIgnoreCase("java")){
                System.out.println("La palabra java se encuentra en la lista, ignorando may�sculas y min�sculas. ");
            }else{
                System.out.println("La palabra java no se encuentra en la lista, ignorando may�sculas y min�sculas. ");
            }
            
            //Remover los espacios en blanco de una cadena trim();
            
            String palabraConEspacios = "    "+palabra+"      ";
            String palabraSinEspacios = palabraConEspacios.trim();
            
            System.out.println("Plabra con espacios : " + palabraConEspacios);
            System.out.println("Palabra sin espacios : " + palabraSinEspacios);
            System.out.println("--------------------------------------------------");
        }
    }
    
}
